// https://github.com/gorhill/uBlock/blob/33a18c3a1eb101470c43979a41d8adef3e21208d/src/web_accessible_resources/noop.js
(function() {
    'use strict';
})();
