const url = new URLSearchParams(window.location.search).get("url");
window.location = url;
